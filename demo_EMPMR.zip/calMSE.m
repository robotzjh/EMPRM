function  RMSE= calMSE(GrtR, GrtT, pM, data, s)


N= length(pM);
Model= [];
Data= [];
pM1(1:4,1:3) = [GrtR{1,1};0 0 0];
pM1(1:4,4) = [GrtT{1,1}*s;1];
for i=1:N
    p(i).M(1:4,1:3) = [GrtR{1,i};0 0 0];
    p(i).M(1:4,4) = [GrtT{1,i}*s;1];
    p(i).M= inv(pM1)* p(i).M;
    R0= p(i).M(1:3,1:3);    t0= p(i).M(1:3,4);
    TData= transform_to_global(data{i}, R0, t0);
    Data= [Data, TData];
    
    R= pM(i).M(1:3,1:3);    t= pM(i).M(1:3,4);
    TModel= transform_to_global(data{i}, R, t);
    Model= [Model,TModel];   
end
Num= size(Data,2);
RMSE= sqrt(sum(sum((Model-Data).^2)')/Num);