function  [R,t]= M2Rt(M)

R=M(1:3,1:3);
t= M(1:3,4);